# HTTP-Caching
A Perl class that one SHOULD use when building a cache for HTTP responses, it's brains are wired according to RFC7234
